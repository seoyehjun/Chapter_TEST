선택지에 있지 않은 숫자 입력시 예외 처리하고 재입력 받습니다
int형을 입력해야 할 곳에 String 입력하면 다시 입력 받습니다. 

class Member : 구매자 판매자가 공통적으로 가져야할 필드, 메서드를 가집니다
class Seller : 판매자가 베타적으로 가지는 필드를 가집니다
class Customer : 구매자가 베타적으로 가지는 필드를 가집니다
class Controller : 문제에서 주문한 기능들을 가지는 함수를 가집니다. 
class Main : 실행코드
